<?php
session_destroy();
echo "<script>location.href='index.php?page=inlogForm';</script> ";
?>
