<form id="loginform" name="inloggen" method="POST" action="" enctype="multipart/form-data">
    <input type="text" class="input" placeholder="E-mail" name="email"/>
    <input type="password" class="input" placeholder="Password" name="password"/>
    <input type="hidden" name="submit" value="true">
    <input type="submit" class="loginbutton" value="login"  style="color: white" id="submit"/>
</form>
