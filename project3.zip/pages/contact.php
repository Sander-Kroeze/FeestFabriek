<h1>eem contact</h1>

<div class="contact-center">
    <div class="contact-border">
        <div class="column1">
            <h2>Locatie:</h2>
            <iframe class="frame" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d606.1865300841308!2d6.6010449292678794!3d52.574202313773284!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c801a53775e10f%3A0x832dec59c260a9b!2sHof%20van%20Otten%201%2C%207771%20CJ%20Hardenberg!5e0!3m2!1snl!2snl!4v1570631693201!5m2!1snl!2snl" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
        </div>
        <div class="column1">
            <h2>Contactgegevens</h2>
            <p>Telefoonnummer: 0612345678</p>
            <p>Postcode: 1234AA</p>
            <p>Adres: Laan van de laan 13</p>
            <p>Email: info@fff.nl</p>
        </div>
    </div>
</div>



