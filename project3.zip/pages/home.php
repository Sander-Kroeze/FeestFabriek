<!--foto gallerij-->
<header>
    <div><img src="img/ballon.jpg"  width="850px" height="520px"></div>
    <div><img src="img/feest.jpg" width="850px" height="520px"></div>
    <div><img src="img/artikelen.jpg"  width="850px" height="520px"></div>
</header>
<!--text-->
<div class="textCenter" id="">
    <p>Welkom bij de Webshop van</p>
    <h1>Fred's Feest Fabriek</h1>
</div>


