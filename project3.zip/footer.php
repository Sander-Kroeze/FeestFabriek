<footer>
    <div class="text-center">Copyright &copy; Fred's Feest Fabriek</div>
</footer>
